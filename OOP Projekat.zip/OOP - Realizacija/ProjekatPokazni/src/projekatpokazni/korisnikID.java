package projekatpokazni;

public class korisnikID {
    
    public static int kID;   
    public static String kIme;
}
